import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import Contact from './components/Contact';
import Slogan from './components/Slogan';
import Livescore from './components/Livescore';
import Topplayers from './components/Topplayers';
import Footer from './components/Footer';

function App() {
  return (
    <div>
      <Navbar />
      <Slogan />
      <Livescore />
      <Topplayers />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
