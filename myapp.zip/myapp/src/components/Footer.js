import React from 'react'
import '../App.css';

const Footer = () => {
  return (
    <div>
        <footer class="footer-distributed">

<div class="footer-left">
  <img src="../Black_Eagle_Gaming_Free_Logo-removebg-preview (2).png"/>
  <h3>Soccer<span>Tech</span></h3>

  <p class="footer-links">
    <a href="">Home</a>
    <br/>
    <a href="">Feedback</a>
    <br/>
    <a href="">About</a>
    <br/>
    <a href="">Contact Us</a>
  </p>

  <p class="footer-company-name">taskforce@aptechgdn.net</p>
</div>

<div class="footer-center">
  <div>
    <i class="fa fa-map-marker"></i>
    <p><span>aptechgdn</span> </p>

  </div>

  <div>
    <i class="fa fa-phone"></i>
    <p>65656565</p>
  </div>
  <div>
    <i class="fa fa-envelope"></i>
    <p><a href="mailto:taskforce@aptechgdn.net">taskforce@aptechgdn.net</a></p>
  </div>
</div>
<div class="footer-right">
  <p class="footer-company-about">
    <span>About soccer</span>
    Soccer is a team sport played by a team of 11 players against another team of 11 players on a field.
    The team has one designated goalkeeper and 10 outfield players.
    Outfield players are usually specialised in attacking or defending or both.
    A team is typically split into defenders, midfielders and forwards, though there is no restriction on players
    moving anywhere
    on the pitch.<br/>
    A group of people, clubs, or countries that have joined together for a particular purpose, or because they share
    a common interest.
  </p>
  <div class="footer-icons">
    <a href="#"><i class="fa fa-facebook text-white"></i></a>
    <a href="#"><i class="fa fa-twitter text-white"></i></a>
    <a href="#"><i class="fa fa-instagram text-white"></i></a>
  </div>
</div>
</footer>
    </div>
  )
}

export default Footer