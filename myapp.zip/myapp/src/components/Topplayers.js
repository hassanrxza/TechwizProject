import React from 'react'
import '../App.css';

const Topplayers = () => {
  return (
    <div>
        <div class="container">
      <table class="table table-striped table-bordered table-hover mt-1 text-center">
          <tr>
              <th colspan="12">10 TOP RANKER</th>
          </tr>
          <tr>
              <th style={{width: "5vw"}}>RANK</th>
              <th>PLAYERS</th>
              <th>COUNTRY</th>
          </tr>
          <tr>
              <td id="p1">1</td>
              <td id="r1">2</td>
              <td id="c1">3</td>
          </tr>
          <tr>
              <td id="p2">1</td>
              <td id="r2">2</td>
              <td id="c2">3</td>
          </tr> <tr>
              <td id="p3">1</td>
              <td id="r3">2</td>
              <td id="c3">3</td>
          </tr> <tr>
              <td id="p4">1</td>
              <td id="r4">2</td>
              <td id="c4">3</td>
          </tr> <tr>
              <td id="p5">1</td>
              <td id="r5">2</td>
              <td id="c5">3</td>
          </tr> <tr>
              <td id="p6">1</td>
              <td id="r6">2</td>
              <td id="c6">3</td>
          </tr> <tr>
              <td id="p7">1</td>
              <td id="r7">2</td>
              <td id="c7">3</td>
          </tr> <tr>
              <td id="p8">1</td>
              <td id="r8">2</td>
              <td id="c8">3</td>
          </tr> <tr>
              <td id="p9">1</td>
              <td id="r9">2</td>
              <td id="c9">3</td>
          </tr> <tr>
              <td id="p10">1</td>
              <td id="r10">2</td>
              <td id="c10">3</td>
          </tr>
      </table>
   </div>

    </div>
  )
}

export default Topplayers