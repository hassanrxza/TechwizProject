import React from 'react'
import '../App.css';

const Livescore = () => {
  return (
    <div>
         <div class="container">
      <div class="row">
        <div class="col-lg-12">
           <h2 class="text-center m-1" >LIVE SCORE</h2>
        </div>
      </div>
      <br/>

       {/* Live Match 1  */}
      <br/><br/>

      <div class="row">
        <div class="col-lg-5">

          <h3 class="text-center" id="country1"><img src="../livescore/logo.png" class="ml-5" alt="" style={{height: "8vh"}} id="logo1"/>team name</h3>
          <p class="text-center" id="time1">score</p>
        </div>
        <div class="col-lg-2">
          <h1 class="text-center">V/S</h1>
          <br/>
          <p class="text-center"><b>timing</b></p>
        </div>
        <div class="col-lg-5">
          <h3 class="text-center" id="country2"><img src="../livescore/logo.png" class="ml-5" alt="" style={{height: "8vh"}} id="logo2"/>team name</h3>
          <p class="text-center" id="time2">score</p>
        </div>
      </div>
      <br/><br/><br/>
       {/* Live Match 2 */}
       <div class="row">
        <div class="col-lg-5">

          <h3 class="text-center" id="country1"><img src="../livescore/logo.png" class="ml-5" alt="" style={{height: "8vh"}}id="logo1"/>team name</h3>
          <p class="text-center" id="time1">score</p>
        </div>
        <div class="col-lg-2">
          <h1 class="text-center">V/S</h1>
          <br/>
          <p class="text-center"><b>timing</b></p>
        </div>
        <div class="col-lg-5">
          <h3 class="text-center" id="country2"><img src="../livescore/logo.png" class="ml-5" alt="" style={{height: "8vh"}} id="logo2"/>team name</h3>
          <p class="text-center" id="time2">score</p>
        </div>
      </div>
      <br/><br/><br/>
     

      
       {/* Live Match 3  */}
       <div class="row">
        <div class="col-lg-5">

          <h3 class="text-center" id="country1"><img src="../livescore/logo.png" class="ml-5" alt="" style={{height: "8vh"}} id="logo1"/>team name</h3>
          <p class="text-center" id="time1">score</p>
        </div>
        <div class="col-lg-2">
          <h1 class="text-center">V/S</h1>
          <br/>
          <p class="text-center"><b>timing</b></p>
        </div>
        <div class="col-lg-5">
          <h3 class="text-center" id="country2"><img src="../livescore/logo.png" class="ml-5" alt="" style={{height: "8vh"}} id="logo2"/>team name</h3>
          <p class="text-center" id="time2">score</p>
        </div>
      </div>
      <br/><br/><br/>
     

    </div>
    </div>
  )
}

export default Livescore