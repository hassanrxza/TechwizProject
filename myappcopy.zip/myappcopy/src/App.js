import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

import Worldcup from './components/Worldcup';
import Playerstats from './components/Playerstats';
import Leage from './components/Leage';

function App() {
  return (
    <div>
      <Router>
      <Navbar /> 
        <Switch>
          <Route path="/"><Worldcup/></Route>
          <Route exact path="/playerstat"><Playerstats/></Route>
          <Route path="/leage"><Leage/></Route>
        </Switch>
      </Router>

    </div>
  );
}

export default App;
