import React from "react"
import '../App.css';
import logo from "../img/logo.png"
import Contact from './Contact';
import Slogan from './Slogan';
import Livescore from './Livescore';
import Topplayers from './Topplayers';
import Footer from './Footer';

import {Link} from "react-router-dom"

const Navbar = () => {
    return (
        <div>
            <header>



<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="#"><img src={logo} alt="SoccerVerse" style={{height : "100px" , width : "100px" , marginLeft : "10%"}}/></a>
        <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto mt-1 mt-lg-0">
                <li class="nav-item ">
                    <Link to="/" class="nav-link active" href="#" aria-current="page">HOME <span class="visually-hidden">(current)</span></Link>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">WORLD<span class="px-1">CUP</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">LEAGUES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">PLAYER<span class="px-1">STATS</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">CONTACT</a>
                </li>
            </ul>
        </div>
  </div>
</nav>

</header>
<Slogan />
      <Livescore />
      <Topplayers />
      <Contact />
      <Footer />
        </div>
    )
}

export default Navbar;