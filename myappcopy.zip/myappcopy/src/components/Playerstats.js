import React from 'react'

const Playerstats = () => {
  return (
    <div>Playerstats</div>
  )
}

export default Playerstats