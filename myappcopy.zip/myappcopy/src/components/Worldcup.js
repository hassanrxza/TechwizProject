import React from 'react'

const Worldcup = () => {
  return (
    <div>Worldcup</div>
  )
}

export default Worldcup