import React from 'react'

const Leage = () => {
  return (
    <div>Leage</div>
  )
}

export default Leage